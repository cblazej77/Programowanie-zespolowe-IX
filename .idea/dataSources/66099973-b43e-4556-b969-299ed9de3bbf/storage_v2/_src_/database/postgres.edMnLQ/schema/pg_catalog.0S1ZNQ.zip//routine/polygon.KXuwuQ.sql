create function polygon(circle) returns polygon
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

alter function polygon(circle) owner to postgres;

