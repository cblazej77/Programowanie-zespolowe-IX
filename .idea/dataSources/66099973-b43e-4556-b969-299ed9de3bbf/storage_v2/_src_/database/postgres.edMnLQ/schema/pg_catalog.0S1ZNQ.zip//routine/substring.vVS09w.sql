create function substring(text, text, text) returns text
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

alter function substring(text, text, text) owner to postgres;

